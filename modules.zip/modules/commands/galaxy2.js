var Faris = "Mr Faris";
const axios = require("axios");
const request = require("request");
const fs = require("fs-extra");

module.exports.config = {
  name: "logo2",
  version: "1.0",
  hasPermssion: 0,
  credits: "mirrykal",
  description: "Generate logos",
  commandCategory: "logo",
  usages: "logo",
  cooldowns: 2,
};

module.exports.run = async function ({ api, event, args, Users }) {
  let { messageID, senderID, threadID } = event;

  if (args.length === 1 && args[0] === "list") {
    const logoTypes = [
      "\n1 : Arrow", "\n2 : Blueneon", "\n3 : Blackpink", "\n4 : yasuologo","\n5 : Arrow2","\n6 : Aov",
      "\n7 : Anonymous ", "\n8 :Eraser", "\n9 : Dragonfire", "\n10 : Cloud", "\n11 : Cloth", "\n12 : Caper ",
      "\n13 : Leafgraphy", "\n14 : Incandescent", "\n15 Horror:  ", "\n16 : Greenbrush", "\n17 : Hallowen", "\n18 : Graffiti","\n19 : Glasses","\n20 : Foggy",
      "\n21 : Crank ", "\n22 :Coverpubg", "\n23 : Yasuologo", "\n24 : Socialbutton", "\n25 : Sunlight", "\n26 : Television","\n27 : Typography","\n28 : Typography2",
      "\n29 : Water ", "\n30 :Warface", "\n31 : American","\n\nFor photoxy Type Prefix photoxy -Comming Soon"
    ];
    return api.sendMessage(`All types of logos:\n\n${logoTypes.join(", ")}`, threadID, messageID);
  }

  if (args.length < 2) {
    return api.sendMessage(`Use: logo number <name>\n to see all logo types: ephoto list`, threadID, messageID);
  }

  let type = args[0].toLowerCase();
  let name = args[1];
  let name2 = args.slice(2).join(" ");
  let pathImg = __dirname + `/cache/${type}_${name}.png`;
  let apiUrl, message;

  switch (type) {
    case "1":
      apiUrl =`https://api.zahwazein.xyz/ephoto/arrow2?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Arrow2』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ";
      break;
    case "2":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Blueneon?apikey=zenzkey_a1780450fcc8text=${name}`;
      message = "『Blueneon』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽";
      break;
    case "3":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Blackpink?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Blackpink』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ";
      break;
    case "4":
      apiUrl = `https://api.zahwazein.xyz/ephoto/yasuologo?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『yasuologo』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
    case "5":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Arrow?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Arrow2』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ";
      break;
    case "6":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Aov?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Aov』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
    case "7":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Anonymous?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Anonymous』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽:";
      break;
    case "8":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Eraser?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Eraser』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽";
      break;
    case "9":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Dragonfire?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Dragonfire』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ";
      break;
    case "10":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Cloud?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Cloud』 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
    case "11":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Cloth?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Cloth』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
    case "12":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Caper?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Caper』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫";
      break;
    case "13":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Leafgraphy?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Leafgraphy』 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ";
      break;
    case "14":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Incandescent?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Incandescent』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽";
      break;
    case "15":
      apiUrl = `https://api.zahwazein.xyz/ephoto/Horror?apikey=zenzkey_a1780450fcc8&text=${name}`;
      message = "『Horror』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ";
      break;
        case "16":
      apiUrl =`https://api.zahwazein.xyz/ephoto/amerGreenbrushican?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Greenbrush』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫";
      break;
        case "17":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Hallowen?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Hallowen』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
       case "18":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Graffiti?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Graffiti』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
       case "19":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Glasses?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Glasses』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
       case "20":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Foggy?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Foggy』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
       case "21":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Crank?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Crank』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
       case "22":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Coverpubg?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Coverpubg』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
       case "23":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Yasuologo?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Yasuologo』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
      case "24":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Socialbutton?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Socialbutton』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
      case "25":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Sunlight?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Sunlight』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
      case "26":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Television?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Television』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
       case "27":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Typography?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Typography』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
        case "28":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Typography2?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Typography2』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫";
      break;
      case "29":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Water?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Water』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫";
      break;
       case "30":
      apiUrl =`https://api.zahwazein.xyz/ephoto/Warface?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『Warface』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ";
      break;
      case "31":
      apiUrl =`https://api.zahwazein.xyz/ephoto/american?apikey=zenzkey_811f405cfea0&text=${name}`;
      message = "『American』 ➫ 𝘽𝙖𝙗𝙮 𝙔𝙖𝙡𝙤 𝘼𝙥𝙣𝙖 𝙇𝙤𝙜𝙤💚🪽 ➫ ";
      break;
       default:
      return api.sendMessage(`𝙄𝙣𝙫𝙖𝙡𝙞𝙙 𝙡𝙤𝙜𝙤 𝙩𝙮𝙥𝙚! 𝙐𝙨𝙚: /ephoto 𝙡𝙞𝙨𝙩 𝙩𝙤 𝙨𝙝𝙤𝙬 𝙖𝙡𝙡 𝙡𝙤𝙜𝙤 𝙩𝙮𝙥𝙚𝙨`, threadID, messageID);
  }


  api.sendMessage("𝘽𝙖𝙗𝙮 𝙏𝙝𝙤𝙧𝙖 𝙒𝙖𝙞𝙩 𝙆𝙖𝙧𝙤 𝑳𝒐𝒈𝒐 𝘽𝙖𝙣 𝙍𝙖𝙝𝙖 𝙃𝙖 𝘼𝙥𝙠𝙖🩵🪽 ", threadID, messageID);
  let response = await axios.get(apiUrl, { responseType: "arraybuffer" });
  let logo = response.data;
  fs.writeFileSync(pathImg, Buffer.from(logo, "utf-8"));
  return api.sendMessage(
    {
      body: message,
      attachment: fs.createReadStream(pathImg),
    },
    threadID,
    () => fs.unlinkSync(pathImg),
    messageID
  );
};